package com.surendramaran.yolov8tflite

object Constants {
    const val MODEL_PATH = "model.tflite"
    const val LABELS_PATH = "labels.txt"
}
